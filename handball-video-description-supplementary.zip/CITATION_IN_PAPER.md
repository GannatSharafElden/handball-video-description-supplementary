# Suggested text for the manuscript

**Methodology (short):**

> The full handball-specific annotation guidance, automated judging prompt, and scoring interpretation are provided in the publicly accessible supplementary materials (GitHub repository: [INSERT PUBLIC REPOSITORY URL]). The evaluated prompts and score definitions are retained there to improve transparency without duplicating them in the manuscript.

**If linking to the exact judge prompt:**

> The complete video-description judge prompt is available in the online supplementary appendix ([INSERT PERMALINK TO appendix/prompts/evaluation_judge_prompt.txt]).

Only use these statements after the repository is published and links have been verified. A URL pinned to a particular Git commit is preferable for manuscript submission.
